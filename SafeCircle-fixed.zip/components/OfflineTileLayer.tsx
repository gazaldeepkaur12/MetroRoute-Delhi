'use client';

import { useEffect, useRef } from 'react';
import { useMap } from 'react-leaflet';
import L from 'leaflet';
// Side-effect import: this augments the global `L` object with
// `L.tileLayer.offline` and `L.control.savetiles`, backed by the browser's
// IndexedDB. No CDN, no external script tag — it's bundled into the app.
import 'leaflet.offline';

const TILE_URL = 'https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png';
const TILE_ATTRIBUTION =
  '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors';

/**
 * Renders nothing itself — it attaches an offline-capable tile layer plus a
 * "Download this area" / "Delete offline tiles" control to the parent
 * <MapContainer>. Tiles you've already downloaded keep working with the
 * network off (or throttled/blocked), which matters at a protest where
 * mobile data is often the first thing to go.
 */
export default function OfflineTileLayer({ zoomLevels }: { zoomLevels: number[] }) {
  const map = useMap();
  const layerRef = useRef<any>(null);
  const controlRef = useRef<any>(null);

  useEffect(() => {
    const L_any = L as any;

    const offlineLayer = L_any.tileLayer.offline(TILE_URL, {
      attribution: TILE_ATTRIBUTION,
      subdomains: 'abc',
      minZoom: 3,
      maxZoom: 18,
    });
    offlineLayer.addTo(map);
    layerRef.current = offlineLayer;

    const saveControl = L_any.control.savetiles(offlineLayer, {
      zoomlevels: zoomLevels,
      confirm(_layer: any, succCallback: () => void) {
        if (window.confirm('Download map tiles for the area currently on screen, for offline use?')) {
          succCallback();
        }
      },
      confirmRemoval(_layer: any, succCallback: () => void) {
        if (window.confirm('Delete all offline map tiles saved on this device?')) {
          succCallback();
        }
      },
      saveText: '⬇ Save this area offline',
      rmText: '🗑 Clear offline tiles',
    });
    saveControl.addTo(map);
    controlRef.current = saveControl;

    return () => {
      if (controlRef.current) map.removeControl(controlRef.current);
      if (layerRef.current) map.removeLayer(layerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [map]);

  return null;
}
