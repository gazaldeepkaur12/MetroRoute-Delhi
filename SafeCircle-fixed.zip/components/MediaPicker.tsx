'use client';

import { useRef, useState } from 'react';
import imageCompression from 'browser-image-compression';

type Props = {
  onUploaded: (mediaUrl: string, mediaType: 'image' | 'audio') => void;
  disabled?: boolean;
};

export default function MediaPicker({ onUploaded, disabled }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow picking the same file again later
    if (!file) return;

    setBusy(true);
    setError(null);
    try {
      // Re-encoding via canvas (what this library does) strips EXIF metadata,
      // which is where GPS coordinates and device info live in photos. This
      // also shrinks upload size, which matters on mobile data at a protest.
      const cleaned = await imageCompression(file, {
        maxSizeMB: 1.5,
        maxWidthOrHeight: 1600,
        useWebWorker: true,
        initialQuality: 0.8,
      });

      const formData = new FormData();
      formData.append('file', cleaned, 'photo.jpg');

      const res = await fetch('/api/media/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Upload failed.');
        return;
      }
      onUploaded(data.mediaUrl, data.mediaType);
    } catch {
      setError('Could not process image.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex items-center gap-2">
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        onChange={handleFile}
        className="hidden"
        disabled={disabled || busy}
      />
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        disabled={disabled || busy}
        title="Attach a photo (metadata is stripped automatically)"
        className="rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-50 px-3 py-2 text-sm"
      >
        {busy ? 'Processing…' : '📷'}
      </button>
      {error && <span className="text-danger-500 text-xs">{error}</span>}
    </div>
  );
}
