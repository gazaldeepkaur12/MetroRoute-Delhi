'use client';

import { useEffect, useState } from 'react';
import { MapContainer, Marker, Popup, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import { supabase } from '@/lib/supabaseClient';
import OfflineTileLayer from './OfflineTileLayer';

// Inline SVG markers, encoded as data URIs — no external image file or CDN
// fetch required, so pins still render with zero network connectivity.
function makeSvgIcon(fillColor: string) {
  const svg = `
    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="40" viewBox="0 0 28 40">
      <path d="M14 0C6.3 0 0 6.3 0 14c0 10.5 14 26 14 26s14-15.5 14-26C28 6.3 21.7 0 14 0z"
            fill="${fillColor}" stroke="#0f172a" stroke-width="1.5"/>
      <circle cx="14" cy="14" r="5.5" fill="#0f172a"/>
    </svg>`;
  return L.icon({
    iconUrl: `data:image/svg+xml;base64,${btoa(svg)}`,
    iconSize: [28, 40],
    iconAnchor: [14, 40],
    popupAnchor: [0, -36],
  });
}

const defaultIcon = makeSvgIcon('#2563eb'); // brand blue, for verified safe spots
const pickedIcon = makeSvgIcon('#16a34a'); // green, for "your suggested location"

type SafeSpot = {
  id: string;
  category: string;
  description: string;
  approx_lat: number;
  approx_lng: number;
};

const CATEGORY_LABELS: Record<string, string> = {
  hiding: '🙈 Hiding spot',
  medical: '🩹 Medical help',
  legal_help: '⚖️ Legal help',
  rest: '🪑 Safe rest area',
  water_food: '🥤 Water / food',
  other: '📍 Other',
};

function LocationPicker({ onPick }: { onPick: (lat: number, lng: number) => void }) {
  useMapEvents({
    click(e) {
      onPick(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
}

export default function SafeSpotsMap({
  center,
  pickMode,
  onPick,
  pickedLocation,
}: {
  center: [number, number];
  pickMode?: boolean;
  onPick?: (lat: number, lng: number) => void;
  pickedLocation?: [number, number] | null;
}) {
  const [spots, setSpots] = useState<SafeSpot[]>([]);

  const CACHE_KEY = 'psc_verified_spots_cache';

  useEffect(() => {
    let active = true;

    // Show whatever we saw last time immediately, in case the network
    // request below fails (no connection right now).
    try {
      const cached = localStorage.getItem(CACHE_KEY);
      if (cached) setSpots(JSON.parse(cached));
    } catch {
      // localStorage unavailable or corrupted cache — ignore, not critical.
    }

    async function load() {
      const { data } = await supabase
        .from('safe_spots')
        .select('id, category, description, approx_lat, approx_lng')
        .eq('status', 'verified');
      if (active && data) {
        setSpots(data as SafeSpot[]);
        try {
          localStorage.setItem(CACHE_KEY, JSON.stringify(data));
        } catch {
          // Storage full or unavailable — the map still works, just without caching.
        }
      }
    }
    load();

    const channel = supabase
      .channel('safe-spots-verified')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'safe_spots' }, load)
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, []);

  return (
    <MapContainer center={center} zoom={14} className="h-full w-full">
      <OfflineTileLayer zoomLevels={[13, 14, 15, 16]} />
      {pickMode && onPick && <LocationPicker onPick={onPick} />}
      {pickedLocation && (
        <Marker position={pickedLocation} icon={pickedIcon}>
          <Popup>Your suggested location (will be shifted slightly for privacy)</Popup>
        </Marker>
      )}
      {spots.map((spot) => (
        <Marker key={spot.id} position={[spot.approx_lat, spot.approx_lng]} icon={defaultIcon}>
          <Popup>
            <strong>{CATEGORY_LABELS[spot.category] ?? spot.category}</strong>
            <p>{spot.description}</p>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
