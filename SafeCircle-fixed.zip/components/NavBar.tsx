'use client';

import Link from 'next/link';
import { useSession } from '@/lib/useSession';

export default function NavBar() {
  const { session, loading, refresh } = useSession();

  async function handleLogout() {
    await fetch('/api/auth/logout', { method: 'POST' });
    await refresh();
    window.location.href = '/';
  }

  return (
    <nav className="sticky top-0 z-50 flex items-center justify-between bg-slate-900/95 backdrop-blur px-4 py-3 border-b border-slate-800">
      <Link href="/" className="font-semibold text-brand-500">
        🛡️ Safe Spots & Chat
      </Link>
      <div className="flex items-center gap-3 text-sm">
        <Link href="/rooms" className="hover:text-brand-500">
          Rooms
        </Link>
        <Link href="/safe-spots" className="hover:text-brand-500">
          Safe Spots
        </Link>
        {!loading && session && (
          <>
            <span className="text-slate-400 hidden sm:inline">@{session.nickname}</span>
            <button
              onClick={handleLogout}
              className="rounded bg-slate-800 px-2 py-1 hover:bg-slate-700"
            >
              Log out
            </button>
          </>
        )}
        {!loading && !session && (
          <Link href="/login" className="rounded bg-brand-600 px-3 py-1 hover:bg-brand-500">
            Log in
          </Link>
        )}
      </div>
    </nav>
  );
}
