'use client';

import { useEffect, useRef, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabaseClient';
import { useSession } from '@/lib/useSession';
import MediaPicker from './MediaPicker';

type Message = {
  id: string;
  room_id: string;
  sender_nickname: string;
  body: string | null;
  media_url: string | null;
  media_type: 'image' | 'video' | 'audio' | null;
  created_at: string;
};

export default function ChatRoom({ roomId, roomName }: { roomId: string; roomName: string }) {
  const { session, loading: sessionLoading } = useSession();
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [pendingMedia, setPendingMedia] = useState<{ url: string; type: 'image' | 'audio' } | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let active = true;

    async function loadHistory() {
      const { data } = await supabase
        .from('messages')
        .select('*')
        .eq('room_id', roomId)
        .order('created_at', { ascending: true })
        .limit(200);
      if (active && data) setMessages(data as Message[]);
    }
    loadHistory();

    const channel = supabase
      .channel(`room-${roomId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` },
        (payload) => {
          setMessages((prev) => [...prev, payload.new as Message]);
        }
      )
      .subscribe();

    return () => {
      active = false;
      supabase.removeChannel(channel);
    };
  }, [roomId]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  async function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim() && !pendingMedia) return;
    setSending(true);
    setError(null);
    try {
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomId,
          body: text.trim() || undefined,
          mediaUrl: pendingMedia?.url,
          mediaType: pendingMedia?.type,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Could not send message.');
        return;
      }
      setText('');
      setPendingMedia(null);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col max-w-xl mx-auto w-full">
      <div className="px-4 py-3 border-b border-slate-800">
        <h1 className="font-semibold">{roomName}</h1>
      </div>

      <div className="flex-1 overflow-y-auto px-4 py-3 flex flex-col gap-2">
        {messages.map((m) => (
          <div key={m.id} className="max-w-[85%] bg-slate-900 rounded-lg px-3 py-2 self-start">
            <p className="text-xs text-brand-500 font-medium">{m.sender_nickname}</p>
            {m.body && <p className="text-sm break-words">{m.body}</p>}
            {m.media_url && m.media_type === 'image' && (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={m.media_url} alt="Shared" className="mt-1 rounded max-h-64 object-cover" />
            )}
            {m.media_url && m.media_type === 'audio' && (
              <audio controls src={m.media_url} className="mt-1 w-full" />
            )}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <div className="px-4 py-3 border-t border-slate-800">
        {sessionLoading ? null : session ? (
          <form onSubmit={handleSend} className="flex flex-col gap-2">
            {pendingMedia && (
              <div className="flex items-center gap-2 text-xs text-slate-400">
                Attachment ready to send
                <button type="button" onClick={() => setPendingMedia(null)} className="text-danger-500">
                  Remove
                </button>
              </div>
            )}
            <div className="flex items-center gap-2">
              <MediaPicker
                onUploaded={(url, type) => setPendingMedia({ url, type })}
                disabled={sending}
              />
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Type a message…"
                maxLength={1000}
                className="flex-1 rounded-lg bg-slate-800 border border-slate-700 px-3 py-2 outline-none focus:border-brand-500"
              />
              <button
                type="submit"
                disabled={sending}
                className="rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50 px-4 py-2 font-medium"
              >
                Send
              </button>
            </div>
            {error && <p className="text-danger-500 text-sm">{error}</p>}
          </form>
        ) : (
          <p className="text-sm text-slate-400 text-center">
            <Link href="/login" className="text-brand-500 underline">
              Log in with a nickname
            </Link>{' '}
            to send messages.
          </p>
        )}
      </div>
    </div>
  );
}
