'use client';

import dynamic from 'next/dynamic';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from '@/lib/useSession';

const SafeSpotsMap = dynamic(() => import('@/components/SafeSpotsMap'), { ssr: false });

const CATEGORIES: { value: string; label: string }[] = [
  { value: 'hiding', label: '🙈 Hiding spot' },
  { value: 'medical', label: '🩹 Medical help' },
  { value: 'legal_help', label: '⚖️ Legal help' },
  { value: 'rest', label: '🪑 Safe rest area' },
  { value: 'water_food', label: '🥤 Water / food' },
  { value: 'other', label: '📍 Other' },
];

type PendingSpot = {
  id: string;
  category: string;
  description: string;
  approx_lat: number;
  approx_lng: number;
  confirmations_count: number;
};

const DEFAULT_CENTER: [number, number] = [28.6139, 77.209]; // New Delhi, generic fallback

export default function SafeSpotsPage() {
  const { session } = useSession();
  const [center, setCenter] = useState<[number, number]>(DEFAULT_CENTER);
  const [mode, setMode] = useState<'view' | 'suggest' | 'confirm'>('view');
  const [picked, setPicked] = useState<[number, number] | null>(null);
  const [category, setCategory] = useState('hiding');
  const [description, setDescription] = useState('');
  const [submitMsg, setSubmitMsg] = useState<string | null>(null);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [pendingSpots, setPendingSpots] = useState<PendingSpot[]>([]);

  useEffect(() => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(
      (pos) => setCenter([pos.coords.latitude, pos.coords.longitude]),
      () => {} // silently keep default center if denied
    );
  }, []);

  async function loadPending() {
    const res = await fetch('/api/safe-spots/pending');
    if (res.ok) {
      const data = await res.json();
      setPendingSpots(data.spots ?? []);
    }
  }

  useEffect(() => {
    if (mode === 'confirm' && session) loadPending();
  }, [mode, session]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!picked) {
      setSubmitError('Tap the map to choose an approximate location first.');
      return;
    }
    setSubmitError(null);
    const res = await fetch('/api/safe-spots/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lat: picked[0], lng: picked[1], category, description }),
    });
    const data = await res.json();
    if (!res.ok) {
      setSubmitError(data.error ?? 'Could not submit.');
      return;
    }
    setSubmitMsg(data.note);
    setDescription('');
    setPicked(null);
  }

  async function handleConfirm(spotId: string) {
    const res = await fetch('/api/safe-spots/confirm', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ spotId }),
    });
    const data = await res.json();
    if (res.ok) {
      loadPending();
    } else {
      alert(data.error ?? 'Could not confirm.');
    }
  }

  return (
    <div className="flex-1 flex flex-col">
      <div className="flex items-center gap-2 px-4 py-3 border-b border-slate-800 overflow-x-auto">
        <button
          onClick={() => setMode('view')}
          className={`text-sm px-3 py-1.5 rounded ${mode === 'view' ? 'bg-brand-600' : 'bg-slate-800'}`}
        >
          View map
        </button>
        <button
          onClick={() => (session ? setMode('suggest') : (window.location.href = '/login'))}
          className={`text-sm px-3 py-1.5 rounded ${mode === 'suggest' ? 'bg-brand-600' : 'bg-slate-800'}`}
        >
          Suggest a spot
        </button>
        <button
          onClick={() => (session ? setMode('confirm') : (window.location.href = '/login'))}
          className={`text-sm px-3 py-1.5 rounded ${mode === 'confirm' ? 'bg-brand-600' : 'bg-slate-800'}`}
        >
          Confirm nearby spots
        </button>
      </div>

      {mode === 'view' && (
        <div className="flex-1 min-h-[60vh]">
          <SafeSpotsMap center={center} />
        </div>
      )}

      {mode === 'suggest' && (
        <div className="flex-1 flex flex-col">
          <div className="h-[45vh]">
            <SafeSpotsMap center={center} pickMode onPick={(lat, lng) => setPicked([lat, lng])} pickedLocation={picked} />
          </div>
          <form onSubmit={handleSubmit} className="p-4 flex flex-col gap-3 max-w-lg mx-auto w-full">
            <p className="text-sm text-slate-400">
              Tap the map above to mark an approximate location — it will be shifted slightly before saving,
              so it&apos;s never exact.
            </p>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="rounded bg-slate-800 border border-slate-700 px-3 py-2"
            >
              {CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe it (e.g. 'Behind the pharmacy, gate usually open')"
              className="rounded bg-slate-800 border border-slate-700 px-3 py-2"
              maxLength={300}
              rows={3}
              required
            />
            {submitError && <p className="text-danger-500 text-sm">{submitError}</p>}
            {submitMsg && <p className="text-safe-500 text-sm">{submitMsg}</p>}
            <button type="submit" className="rounded bg-brand-600 hover:bg-brand-500 py-2 font-medium">
              Submit for peer confirmation
            </button>
          </form>
        </div>
      )}

      {mode === 'confirm' && (
        <div className="flex-1 max-w-lg mx-auto w-full px-4 py-4 flex flex-col gap-3">
          <p className="text-sm text-slate-400">
            These are pending suggestions from other users. Confirm ones you know to be accurate — a spot
            needs a few confirmations before it shows up on the public map.
          </p>
          {pendingSpots.length === 0 && <p className="text-slate-500 text-sm">Nothing pending right now.</p>}
          {pendingSpots.map((spot) => (
            <div key={spot.id} className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-2">
              <p className="font-medium">{CATEGORIES.find((c) => c.value === spot.category)?.label ?? spot.category}</p>
              <p className="text-sm text-slate-300">{spot.description}</p>
              <p className="text-xs text-slate-500">{spot.confirmations_count} confirmation(s) so far</p>
              <button
                onClick={() => handleConfirm(spot.id)}
                className="self-start rounded bg-safe-600 hover:bg-safe-500 px-3 py-1.5 text-sm"
              >
                Confirm this spot
              </button>
            </div>
          ))}
        </div>
      )}

      {!session && (
        <p className="text-center text-sm text-slate-500 py-2">
          <Link href="/login" className="text-brand-500 underline">
            Log in
          </Link>{' '}
          to suggest or confirm safe spots.
        </p>
      )}
    </div>
  );
}
