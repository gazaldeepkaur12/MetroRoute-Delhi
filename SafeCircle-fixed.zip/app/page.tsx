import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 text-center gap-6 max-w-lg mx-auto">
      <h1 className="text-2xl font-bold text-brand-500">Protest Chat & Safe Spots</h1>
      <p className="text-slate-300">
        A nickname-only space to coordinate safely, share know-your-rights info, and find
        peer-verified safe spots nearby. No phone number, email, or ID required — ever.
      </p>

      <div className="grid grid-cols-1 gap-3 w-full">
        <Link href="/login" className="rounded-lg bg-brand-600 hover:bg-brand-500 py-3 font-medium">
          Get a nickname & log in
        </Link>
        <Link href="/rooms" className="rounded-lg bg-slate-800 hover:bg-slate-700 py-3 font-medium">
          Browse chat rooms
        </Link>
        <Link href="/safe-spots" className="rounded-lg bg-slate-800 hover:bg-slate-700 py-3 font-medium">
          View safe spots map
        </Link>
      </div>

      <div className="text-left text-sm text-slate-400 bg-slate-900 border border-slate-800 rounded-lg p-4 mt-4">
        <p className="font-semibold text-slate-200 mb-1">A few things by design:</p>
        <ul className="list-disc list-inside space-y-1">
          <li>Your account is a nickname + password only — no real identity is ever collected.</li>
          <li>Safe-spot locations are rounded/shifted before saving, never exact GPS.</li>
          <li>A spot only appears on the public map after other users confirm it.</li>
          <li>This app is for peaceful organizing, mutual aid, and legal/medical help — not for planning
            unlawful acts.</li>
        </ul>
      </div>
    </div>
  );
}
