import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';
import { checkRateLimit } from '@/lib/rateLimit';

const MAX_BODY_LENGTH = 1000;

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const roomId = typeof body?.roomId === 'string' ? body.roomId : '';
  const text = typeof body?.body === 'string' ? body.body.trim() : '';
  const mediaUrl = typeof body?.mediaUrl === 'string' ? body.mediaUrl : null;
  const mediaType = typeof body?.mediaType === 'string' ? body.mediaType : null;

  if (!roomId) {
    return NextResponse.json({ error: 'roomId is required.' }, { status: 400 });
  }
  if (!text && !mediaUrl) {
    return NextResponse.json({ error: 'Message must have text or media.' }, { status: 400 });
  }
  if (text.length > MAX_BODY_LENGTH) {
    return NextResponse.json({ error: `Message too long (max ${MAX_BODY_LENGTH} characters).` }, { status: 400 });
  }

  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('is_muted')
    .eq('id', session.profileId)
    .maybeSingle();

  if (profile?.is_muted) {
    return NextResponse.json({ error: 'Your account has been muted for this session.' }, { status: 403 });
  }

  const rateLimit = await checkRateLimit(session.profileId, 'message');
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `You're sending messages too fast. Try again in ${rateLimit.retryAfterSeconds}s.` },
      { status: 429 }
    );
  }

  const { data: inserted, error } = await supabaseAdmin
    .from('messages')
    .insert({
      room_id: roomId,
      sender_nickname: session.nickname,
      sender_profile_id: session.profileId,
      body: text || null,
      media_url: mediaUrl,
      media_type: mediaType,
    })
    .select()
    .single();

  if (error || !inserted) {
    return NextResponse.json({ error: 'Could not send message.' }, { status: 500 });
  }

  return NextResponse.json({ message: inserted });
}
