import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';
import { checkRateLimit } from '@/lib/rateLimit';

// Number of distinct peer confirmations required before a spot goes public.
const CONFIRMATIONS_REQUIRED = 3;

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const spotId = typeof body?.spotId === 'string' ? body.spotId : '';
  if (!spotId) return NextResponse.json({ error: 'spotId is required.' }, { status: 400 });

  const rateLimit = await checkRateLimit(session.profileId, 'confirmation');
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Too many confirmations. Try again in ${rateLimit.retryAfterSeconds}s.` },
      { status: 429 }
    );
  }

  const { data: spot } = await supabaseAdmin
    .from('safe_spots')
    .select('id, status, submitted_by, confirmations_count')
    .eq('id', spotId)
    .maybeSingle();

  if (!spot || spot.status !== 'pending') {
    return NextResponse.json({ error: 'This spot is not awaiting confirmation.' }, { status: 400 });
  }
  if (spot.submitted_by === session.profileId) {
    return NextResponse.json({ error: 'You cannot confirm your own submission.' }, { status: 403 });
  }

  // Dedup: primary key (spot_id, profile_id) rejects a second confirmation
  // from the same profile.
  const { error: confirmError } = await supabaseAdmin
    .from('safe_spot_confirmations')
    .insert({ spot_id: spotId, profile_id: session.profileId });

  if (confirmError) {
    // Unique violation = already confirmed by this profile.
    return NextResponse.json({ error: 'You already confirmed this spot.' }, { status: 409 });
  }

  const newCount = spot.confirmations_count + 1;
  const shouldVerify = newCount >= CONFIRMATIONS_REQUIRED;

  const { error: updateError } = await supabaseAdmin
    .from('safe_spots')
    .update({
      confirmations_count: newCount,
      status: shouldVerify ? 'verified' : 'pending',
      verified_at: shouldVerify ? new Date().toISOString() : null,
    })
    .eq('id', spotId);

  if (updateError) {
    return NextResponse.json({ error: 'Could not record confirmation.' }, { status: 500 });
  }

  return NextResponse.json({
    confirmations_count: newCount,
    verified: shouldVerify,
    remaining: shouldVerify ? 0 : CONFIRMATIONS_REQUIRED - newCount,
  });
}
