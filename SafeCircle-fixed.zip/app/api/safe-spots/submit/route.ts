import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';
import { checkRateLimit } from '@/lib/rateLimit';
import { roundAndJitterLocation, isValidLatLng } from '@/lib/geo';

const CATEGORIES = ['hiding', 'medical', 'legal_help', 'rest', 'water_food', 'other'] as const;

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const lat = Number(body?.lat);
  const lng = Number(body?.lng);
  const category = typeof body?.category === 'string' ? body.category : '';
  const description = typeof body?.description === 'string' ? body.description.trim() : '';

  if (!isValidLatLng(lat, lng)) {
    return NextResponse.json({ error: 'A valid approximate location is required.' }, { status: 400 });
  }
  if (!CATEGORIES.includes(category as (typeof CATEGORIES)[number])) {
    return NextResponse.json({ error: 'Invalid category.' }, { status: 400 });
  }
  if (description.length < 5 || description.length > 300) {
    return NextResponse.json({ error: 'Description must be 5-300 characters.' }, { status: 400 });
  }

  const rateLimit = await checkRateLimit(session.profileId, 'safe_spot_submit');
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Too many submissions. Try again in ${rateLimit.retryAfterSeconds}s.` },
      { status: 429 }
    );
  }

  // Precise lat/lng from the browser is used ONLY to compute the rounded/
  // jittered value below — it is never stored anywhere, logged, or returned.
  const { approx_lat, approx_lng } = roundAndJitterLocation(lat, lng);

  const { data: created, error } = await supabaseAdmin
    .from('safe_spots')
    .insert({
      category,
      description,
      approx_lat,
      approx_lng,
      status: 'pending',
      submitted_by: session.profileId,
    })
    .select('id, category, description, status, created_at')
    .single();

  if (error || !created) {
    return NextResponse.json({ error: 'Could not submit safe spot.' }, { status: 500 });
  }

  return NextResponse.json({
    spot: created,
    note: 'Thanks — this will appear on the map for everyone once other users confirm it nearby.',
  });
}
