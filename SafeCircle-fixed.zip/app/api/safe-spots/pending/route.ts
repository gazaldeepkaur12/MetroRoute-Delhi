import { NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';

// Only reachable by a logged-in session — pending spots are not part of the
// public anon-readable surface (see supabase/schema.sql RLS notes).
export async function GET() {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const { data, error } = await supabaseAdmin
    .from('safe_spots')
    .select('id, category, description, approx_lat, approx_lng, confirmations_count, created_at, submitted_by')
    .eq('status', 'pending')
    .neq('submitted_by', session.profileId) // can't confirm your own submission
    .order('created_at', { ascending: false })
    .limit(50);

  if (error) return NextResponse.json({ error: 'Could not load pending spots.' }, { status: 500 });

  // Strip submitted_by before returning — the confirming user doesn't need
  // to know who submitted it, only that it needs review.
  const spots = (data ?? []).map(({ submitted_by, ...rest }) => rest);
  return NextResponse.json({ spots });
}
