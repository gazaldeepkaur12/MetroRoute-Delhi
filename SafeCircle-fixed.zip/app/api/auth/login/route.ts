import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { createSessionCookie } from '@/lib/session';

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const nickname = typeof body?.nickname === 'string' ? body.nickname.trim() : '';
  const password = typeof body?.password === 'string' ? body.password : '';

  if (!nickname || !password) {
    return NextResponse.json({ error: 'Nickname and password are required.' }, { status: 400 });
  }

  const { data: profile } = await supabaseAdmin
    .from('profiles')
    .select('id, nickname, password_hash, is_muted')
    .eq('nickname', nickname)
    .maybeSingle();

  // Same error for "no such nickname" and "wrong password" — don't help
  // anyone enumerate which nicknames exist.
  const genericError = NextResponse.json({ error: 'Incorrect nickname or password.' }, { status: 401 });

  if (!profile) return genericError;

  const passwordMatches = await bcrypt.compare(password, profile.password_hash);
  if (!passwordMatches) return genericError;

  await createSessionCookie({ profileId: profile.id, nickname: profile.nickname });

  await supabaseAdmin.from('profiles').update({ last_seen_at: new Date().toISOString() }).eq('id', profile.id);

  return NextResponse.json({ profileId: profile.id, nickname: profile.nickname, isMuted: profile.is_muted });
}
