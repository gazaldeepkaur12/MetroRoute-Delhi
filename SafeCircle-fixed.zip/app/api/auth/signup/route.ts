import { NextRequest, NextResponse } from 'next/server';
import bcrypt from 'bcryptjs';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { createSessionCookie } from '@/lib/session';

const NICKNAME_REGEX = /^[a-zA-Z0-9_\-]{3,24}$/;

export async function POST(req: NextRequest) {
  const body = await req.json().catch(() => null);
  const nickname = typeof body?.nickname === 'string' ? body.nickname.trim() : '';
  const password = typeof body?.password === 'string' ? body.password : '';

  if (!NICKNAME_REGEX.test(nickname)) {
    return NextResponse.json(
      { error: 'Nickname must be 3-24 characters: letters, numbers, _ or - only. No real names, please.' },
      { status: 400 }
    );
  }
  if (password.length < 8) {
    return NextResponse.json({ error: 'Password must be at least 8 characters.' }, { status: 400 });
  }

  const { data: existing } = await supabaseAdmin
    .from('profiles')
    .select('id')
    .eq('nickname', nickname)
    .maybeSingle();

  if (existing) {
    return NextResponse.json({ error: 'That nickname is already taken.' }, { status: 409 });
  }

  const passwordHash = await bcrypt.hash(password, 12);

  const { data: created, error } = await supabaseAdmin
    .from('profiles')
    .insert({ nickname, password_hash: passwordHash })
    .select('id, nickname')
    .single();

  if (error || !created) {
    return NextResponse.json({ error: 'Could not create account. Try again.' }, { status: 500 });
  }

  await createSessionCookie({ profileId: created.id, nickname: created.nickname });

  return NextResponse.json({ profileId: created.id, nickname: created.nickname });
}
