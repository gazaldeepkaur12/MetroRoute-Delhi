import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';

const MAX_BYTES = 8 * 1024 * 1024; // 8MB
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'audio/webm', 'audio/mp4'];

// NOTE: EXIF stripping (which removes embedded GPS + device metadata from
// photos) happens on the CLIENT before the file ever reaches this route —
// see components/MediaPicker.tsx. This route additionally never stores the
// original filename, and generates a random storage path so uploads can't
// be correlated with a device or session by name.
export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const formData = await req.formData().catch(() => null);
  const file = formData?.get('file');

  if (!file || !(file instanceof File)) {
    return NextResponse.json({ error: 'No file provided.' }, { status: 400 });
  }
  if (!ALLOWED_TYPES.includes(file.type)) {
    return NextResponse.json({ error: 'Unsupported file type.' }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return NextResponse.json({ error: 'File too large (max 8MB).' }, { status: 400 });
  }

  const ext = file.type.split('/')[1] ?? 'bin';
  const randomName = `${crypto.randomUUID()}.${ext}`;
  const path = `${session.profileId.slice(0, 8)}/${randomName}`;

  const arrayBuffer = await file.arrayBuffer();

  const { error } = await supabaseAdmin.storage
    .from('chat-media')
    .upload(path, arrayBuffer, { contentType: file.type, upsert: false });

  if (error) {
    return NextResponse.json({ error: 'Upload failed.' }, { status: 500 });
  }

  const { data: publicUrlData } = supabaseAdmin.storage.from('chat-media').getPublicUrl(path);

  const mediaType = file.type.startsWith('image/') ? 'image' : 'audio';

  return NextResponse.json({ mediaUrl: publicUrlData.publicUrl, mediaType });
}
