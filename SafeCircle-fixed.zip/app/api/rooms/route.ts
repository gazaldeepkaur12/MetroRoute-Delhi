import { NextRequest, NextResponse } from 'next/server';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import { getSession } from '@/lib/session';
import { checkRateLimit } from '@/lib/rateLimit';

function slugify(name: string) {
  return name
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
    .slice(0, 40);
}

export async function GET() {
  // Rooms are globally visible to everyone, logged in or not.
  const { data, error } = await supabaseAdmin
    .from('rooms')
    .select('id, slug, name, description, is_fixed, created_at')
    .order('is_fixed', { ascending: false })
    .order('created_at', { ascending: true });

  if (error) return NextResponse.json({ error: 'Could not load rooms.' }, { status: 500 });
  return NextResponse.json({ rooms: data });
}

export async function POST(req: NextRequest) {
  const session = await getSession();
  if (!session) {
    return NextResponse.json({ error: 'You need to log in first.' }, { status: 401 });
  }

  const body = await req.json().catch(() => null);
  const name = typeof body?.name === 'string' ? body.name.trim() : '';
  const description = typeof body?.description === 'string' ? body.description.trim().slice(0, 200) : '';

  if (name.length < 2 || name.length > 40) {
    return NextResponse.json({ error: 'Room name must be 2-40 characters.' }, { status: 400 });
  }

  const rateLimit = await checkRateLimit(session.profileId, 'room_create');
  if (!rateLimit.allowed) {
    return NextResponse.json(
      { error: `Too many rooms created. Try again in ${rateLimit.retryAfterSeconds}s.` },
      { status: 429 }
    );
  }

  let slug = slugify(name);
  const { data: existing } = await supabaseAdmin.from('rooms').select('id').eq('slug', slug).maybeSingle();
  if (existing) {
    slug = `${slug}-${Math.random().toString(36).slice(2, 6)}`;
  }

  const { data: created, error } = await supabaseAdmin
    .from('rooms')
    .insert({ slug, name, description, is_fixed: false, created_by: session.profileId })
    .select()
    .single();

  if (error || !created) {
    return NextResponse.json({ error: 'Could not create room.' }, { status: 500 });
  }

  return NextResponse.json({ room: created });
}
