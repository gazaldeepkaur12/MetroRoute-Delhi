import { notFound } from 'next/navigation';
import { supabaseAdmin } from '@/lib/supabaseAdmin';
import ChatRoom from '@/components/ChatRoom';

export default async function RoomPage({ params }: { params: { slug: string } }) {
  const { data: room } = await supabaseAdmin
    .from('rooms')
    .select('id, name, slug')
    .eq('slug', params.slug)
    .maybeSingle();

  if (!room) notFound();

  return <ChatRoom roomId={room.id} roomName={room.name} />;
}
