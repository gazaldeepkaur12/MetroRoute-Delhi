'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useSession } from '@/lib/useSession';

type Room = {
  id: string;
  slug: string;
  name: string;
  description: string;
  is_fixed: boolean;
};

export default function RoomsPage() {
  const { session } = useSession();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreate, setShowCreate] = useState(false);
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [error, setError] = useState<string | null>(null);

  async function loadRooms() {
    setLoading(true);
    const res = await fetch('/api/rooms');
    const data = await res.json();
    setRooms(data.rooms ?? []);
    setLoading(false);
  }

  useEffect(() => {
    loadRooms();
  }, []);

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    const res = await fetch('/api/rooms', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, description }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? 'Could not create room.');
      return;
    }
    setName('');
    setDescription('');
    setShowCreate(false);
    loadRooms();
  }

  return (
    <div className="flex-1 max-w-xl mx-auto w-full px-4 py-6 flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <h1 className="text-xl font-bold">Chat rooms</h1>
        {session ? (
          <button
            onClick={() => setShowCreate((v) => !v)}
            className="text-sm rounded bg-brand-600 hover:bg-brand-500 px-3 py-1.5"
          >
            {showCreate ? 'Cancel' : '+ New room'}
          </button>
        ) : (
          <Link href="/login" className="text-sm text-brand-500 underline">
            Log in to create a room
          </Link>
        )}
      </div>

      {showCreate && (
        <form onSubmit={handleCreate} className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex flex-col gap-3">
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Room name"
            className="rounded bg-slate-800 border border-slate-700 px-3 py-2"
            maxLength={40}
            required
          />
          <input
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Short description (optional)"
            className="rounded bg-slate-800 border border-slate-700 px-3 py-2"
            maxLength={200}
          />
          {error && <p className="text-danger-500 text-sm">{error}</p>}
          <button type="submit" className="rounded bg-brand-600 hover:bg-brand-500 py-2 font-medium">
            Create room (visible to everyone)
          </button>
        </form>
      )}

      {loading ? (
        <p className="text-slate-400">Loading rooms…</p>
      ) : (
        <ul className="flex flex-col gap-2">
          {rooms.map((room) => (
            <li key={room.id}>
              <Link
                href={`/rooms/${room.slug}`}
                className="block bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-lg p-4"
              >
                <div className="flex items-center gap-2">
                  <span className="font-medium">{room.name}</span>
                  {room.is_fixed && (
                    <span className="text-[10px] uppercase tracking-wide bg-brand-600/30 text-brand-500 px-1.5 py-0.5 rounded">
                      Official
                    </span>
                  )}
                </div>
                {room.description && <p className="text-sm text-slate-400 mt-1">{room.description}</p>}
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
