'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const router = useRouter();
  const [mode, setMode] = useState<'login' | 'signup'>('signup');
  const [nickname, setNickname] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch(`/api/auth/${mode}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ nickname, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Something went wrong.');
        return;
      }
      router.push('/rooms');
      router.refresh();
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex-1 flex flex-col items-center justify-center px-6 py-10 max-w-sm mx-auto w-full gap-4">
      <h1 className="text-xl font-bold">{mode === 'signup' ? 'Choose a nickname' : 'Log in'}</h1>
      <p className="text-sm text-slate-400 text-center">
        Pick something that isn&apos;t your real name. Your password is only used to protect this
        pseudonym — we never ask for a phone number, email, or ID.
      </p>

      <form onSubmit={handleSubmit} className="w-full flex flex-col gap-3">
        <input
          type="text"
          placeholder="Nickname (e.g. quiet_river42)"
          value={nickname}
          onChange={(e) => setNickname(e.target.value)}
          className="rounded-lg bg-slate-800 border border-slate-700 px-3 py-3 outline-none focus:border-brand-500"
          minLength={3}
          maxLength={24}
          required
        />
        <input
          type="password"
          placeholder="Password (min 8 characters)"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="rounded-lg bg-slate-800 border border-slate-700 px-3 py-3 outline-none focus:border-brand-500"
          minLength={8}
          required
        />

        {error && <p className="text-danger-500 text-sm">{error}</p>}

        <button
          type="submit"
          disabled={submitting}
          className="rounded-lg bg-brand-600 hover:bg-brand-500 disabled:opacity-50 py-3 font-medium"
        >
          {submitting ? 'Please wait…' : mode === 'signup' ? 'Create account' : 'Log in'}
        </button>
      </form>

      <button
        onClick={() => setMode(mode === 'signup' ? 'login' : 'signup')}
        className="text-sm text-brand-500 underline"
      >
        {mode === 'signup' ? 'Already have a nickname? Log in' : "New here? Create a nickname"}
      </button>
    </div>
  );
}
