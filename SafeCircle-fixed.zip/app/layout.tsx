import type { Metadata } from 'next';
import './globals.css';
import NavBar from '@/components/NavBar';

export const metadata: Metadata = {
  title: 'Protest Chat & Safe Spots',
  description: 'Nickname-only chat and verified safe-spot map for protesters. No real names required.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen flex flex-col">
        <NavBar />
        <main className="flex-1 flex flex-col">{children}</main>
        <footer className="text-center text-xs text-slate-500 py-3 border-t border-slate-800 px-4">
          This app is for peaceful, rights-focused organizing only. Know your rights, stay safe, look out for
          each other. No real names, phone numbers, or ID photos are ever requested.
        </footer>
      </body>
    </html>
  );
}
