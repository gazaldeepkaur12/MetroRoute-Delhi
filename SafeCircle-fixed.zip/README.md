# Protest Chat & Safe Spots

A nickname-only, privacy-first chat and safe-spot map for protesters. Built with
Next.js (App Router), Supabase (Postgres + Realtime + Storage), Tailwind CSS,
and Leaflet/OpenStreetMap.

## Core safety principles (please read before changing anything)

- **No real identity, ever.** Accounts are a self-chosen nickname + password.
  No phone number, email, government ID, or "live selfie" is collected. See
  `app/api/auth/*` and `supabase/schema.sql`'s comments for why.
- **Locations are never exact.** Safe-spot coordinates are rounded and
  jittered by ~100-150m server-side (`lib/geo.ts`) before they're ever
  written to the database. The precise point you tap on the map is used only
  to compute that fuzzy value and is never stored or logged.
- **Verification is peer-based, not photo-based.** A submitted safe spot
  needs a few other users to confirm it (`CONFIRMATIONS_REQUIRED` in
  `app/api/safe-spots/confirm/route.ts`) before it appears on the public map.
  We deliberately do **not** require a live camera photo to verify a spot —
  a photo taken at a protest is exactly the kind of evidence that can be used
  to place someone at an event after the fact.
- **Photos shared in chat have their metadata stripped** client-side before
  upload (`components/MediaPicker.tsx`), which removes embedded GPS/device
  info that would otherwise travel inside the image file.
- **Least-privilege database access.** The anon/public Supabase key can only
  ever `SELECT` public data (rooms, messages, verified safe spots). Every
  write goes through a Next.js route handler using the service-role key, so
  every write passes through our own session check + rate limit first. See
  the RLS policies and comments in `supabase/schema.sql`.
- **Rate limiting** on messages, room creation, safe-spot submissions, and
  confirmations (`lib/rateLimit.ts`) to reduce spam/flooding without needing
  real identity to do it.
- **Offline map tiles.** Mobile data is often the first thing that's cut or
  throttled around a protest. The safe-spots map lets a user tap "Save this
  area offline" *before* they need it — tiles are cached in the browser's
  IndexedDB via `leaflet.offline` (`components/OfflineTileLayer.tsx`), and
  the last-seen list of verified spots is cached in `localStorage` so the
  map isn't blank the moment connectivity drops. Marker icons are inline
  SVG data URIs rather than image files fetched from a CDN, so pins render
  with zero network too. **Scope note:** this caches map tiles and the last
  fetched spot list only — it does not make the whole app (chat, login,
  live confirmations) work with no connection, since those inherently need
  a live connection to Supabase. If you want the full app shell to load
  offline too, the next step would be a service worker + PWA manifest for
  static asset caching, deliberately left out here to keep scope to what
  was asked for.

## What's intentionally NOT in this MVP, and why

- **No mandatory live-camera verification photos.** See above — this would
  turn the app into evidence against its own users.
- **No persistent public profile / follower graph** (the "Instagram-style
  IDs" idea from early scoping). Nicknames are accounts, but there's no
  public bio, follower list, or cross-room activity history — that kind of
  durable, browsable identity is exactly what makes deanonymization easier.
- **No group video calls in open rooms.** Real-time video in a
  publicly-joinable room is trivial for a hostile observer to sit in and
  record faces. If you want to add calling, scope it to **1:1, opt-in only**
  calls between two specific nicknames (e.g. via a WebRTC library like
  `simple-peer` or a hosted service like Daily/Twilio, with signaling
  through a Supabase Realtime channel). That's a meaningful chunk of
  additional work (TURN/STUN server, call UI, permissions) intentionally
  left out of this pass so the core chat + safe-spots flow could be solid
  and reviewed first.
- **No Canva/ElevenLabs/Spotify integrations.** These don't serve the app's
  safety purpose and add external API surface for no protective benefit.

## Setup

1. **Clone and install:**
   ```bash
   npm install
   ```

2. **Create a Supabase project** (or use an existing one) at
   [supabase.com](https://supabase.com).

3. **Run the schema:** open the Supabase SQL Editor and run the entire
   contents of `supabase/schema.sql`. This creates all tables, RLS policies,
   the three fixed rooms, and the `chat-media` storage bucket.

4. **Copy the env file and fill in your own values:**
   ```bash
   cp .env.local.example .env.local
   ```
   Fill in `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and
   `SUPABASE_SERVICE_ROLE_KEY` from your Supabase project's API settings, and
   generate a `SESSION_JWT_SECRET` with `openssl rand -base64 32`.

   **Never commit `.env.local` or paste real keys into chat, issues, or
   PRs.** If a key is ever exposed, rotate it in the Supabase dashboard.

5. **Run locally:**
   ```bash
   npm run dev
   ```

6. **Deploy to Vercel:** push to a Git repo, import into Vercel, and add the
   same environment variables in Vercel's Project Settings → Environment
   Variables (not in any committed file).

## Project structure

```
app/
  api/
    auth/{signup,login,logout,me}   - nickname/password session (no real ID)
    messages/                        - send a chat message (rate-limited)
    rooms/                           - list/create rooms
    safe-spots/{submit,confirm,pending} - safe spot lifecycle
    media/upload/                    - stores already EXIF-stripped media
  rooms/                             - room list + [slug] chat page
  safe-spots/                        - map, suggest, confirm UI
  login/                             - nickname/password form
lib/
  supabaseClient.ts   - browser (anon key) client
  supabaseAdmin.ts    - server-only (service role) client
  session.ts          - signed session cookie (jose)
  geo.ts              - location rounding/jitter
  rateLimit.ts         - simple per-action rate limiting
components/
  ChatRoom.tsx, MediaPicker.tsx, SafeSpotsMap.tsx, OfflineTileLayer.tsx, NavBar.tsx
supabase/
  schema.sql          - full schema + RLS policies, heavily commented
```

## A note on scope and legality

This tool is built to support **peaceful, rights-focused organizing**:
know-your-rights info, mutual aid coordination, and finding safe places to
rest, get medical help, or get legal help. It is not designed for, and
should not be used for, planning unlawful acts. Group admins/moderators
should remove content that crosses into planning violence or property
destruction.
