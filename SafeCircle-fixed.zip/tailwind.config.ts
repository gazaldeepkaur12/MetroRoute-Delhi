import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{ts,tsx}',
    './components/**/*.{ts,tsx}',
  ],
  theme: {
    extend: {
      colors: {
        // High-contrast, low-eye-strain palette for outdoor/night use.
        brand: {
          50: '#eef6ff',
          100: '#d9ecff',
          500: '#2563eb',
          600: '#1d4ed8',
          700: '#1e40af',
        },
        danger: {
          500: '#dc2626',
          600: '#b91c1c',
        },
        safe: {
          500: '#16a34a',
          600: '#15803d',
        },
      },
    },
  },
  plugins: [],
};

export default config;
