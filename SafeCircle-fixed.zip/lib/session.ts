import 'server-only';
import { SignJWT, jwtVerify } from 'jose';
import { cookies } from 'next/headers';

const COOKIE_NAME = 'psc_session';
const SESSION_DURATION_SECONDS = 60 * 60 * 24 * 14; // 14 days

function getSecretKey() {
  const secret = process.env.SESSION_JWT_SECRET;
  if (!secret) {
    throw new Error('Missing SESSION_JWT_SECRET in .env.local');
  }
  return new TextEncoder().encode(secret);
}

export type SessionPayload = {
  profileId: string;
  nickname: string;
};

// Deliberately minimal: no IP, no device fingerprint, no real name.
// Just enough to know "which pseudonymous account is this request from".
export async function createSessionCookie(payload: SessionPayload) {
  const token = await new SignJWT({ ...payload })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DURATION_SECONDS}s`)
    .sign(getSecretKey());

  cookies().set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_DURATION_SECONDS,
  });
}

export async function getSession(): Promise<SessionPayload | null> {
  const token = cookies().get(COOKIE_NAME)?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, getSecretKey());
    if (typeof payload.profileId === 'string' && typeof payload.nickname === 'string') {
      return { profileId: payload.profileId, nickname: payload.nickname };
    }
    return null;
  } catch {
    return null;
  }
}

export function clearSessionCookie() {
  cookies().delete(COOKIE_NAME);
}
