/**
 * Rounds a coordinate to reduce precision, then adds a small deterministic-ish
 * random jitter, so the stored location is only accurate to roughly 100-150m.
 * This is applied SERVER-SIDE before any safe-spot insert — the precise
 * coordinate the browser reports is never persisted or sent to other users.
 *
 * ~0.001 degrees of latitude ≈ 111m. We round to 3 decimal places and add
 * up to +/- 0.0007 degrees of jitter (~75m) in a random direction.
 */
export function roundAndJitterLocation(lat: number, lng: number) {
  const round = (n: number) => Math.round(n * 1000) / 1000;

  const jitterAmount = 0.0007;
  const jitterLat = (Math.random() - 0.5) * 2 * jitterAmount;
  const jitterLng = (Math.random() - 0.5) * 2 * jitterAmount;

  return {
    approx_lat: round(lat + jitterLat),
    approx_lng: round(lng + jitterLng),
  };
}

export function isValidLatLng(lat: number, lng: number) {
  return (
    typeof lat === 'number' &&
    typeof lng === 'number' &&
    lat >= -90 &&
    lat <= 90 &&
    lng >= -180 &&
    lng <= 180 &&
    !Number.isNaN(lat) &&
    !Number.isNaN(lng)
  );
}
