import 'server-only';
import { supabaseAdmin } from './supabaseAdmin';

type RateLimitAction = 'message' | 'safe_spot_submit' | 'confirmation' | 'room_create';

const LIMITS: Record<RateLimitAction, { max: number; windowSeconds: number }> = {
  message: { max: 15, windowSeconds: 30 }, // ~1 msg every 2s, bursts allowed
  safe_spot_submit: { max: 5, windowSeconds: 3600 },
  confirmation: { max: 30, windowSeconds: 3600 },
  room_create: { max: 3, windowSeconds: 3600 },
};

/**
 * Returns { allowed: true } or { allowed: false, retryAfterSeconds } for a
 * given profile + action. Uses a simple fixed-window counter stored in
 * Postgres — good enough to stop flooding/spam without adding infra.
 */
export async function checkRateLimit(profileId: string, action: RateLimitAction) {
  const { max, windowSeconds } = LIMITS[action];
  const now = new Date();

  const { data: existing } = await supabaseAdmin
    .from('rate_limits')
    .select('window_start, count')
    .eq('profile_id', profileId)
    .eq('action', action)
    .maybeSingle();

  if (!existing) {
    await supabaseAdmin
      .from('rate_limits')
      .insert({ profile_id: profileId, action, window_start: now.toISOString(), count: 1 });
    return { allowed: true as const };
  }

  const windowStart = new Date(existing.window_start);
  const elapsedSeconds = (now.getTime() - windowStart.getTime()) / 1000;

  if (elapsedSeconds > windowSeconds) {
    // New window
    await supabaseAdmin
      .from('rate_limits')
      .update({ window_start: now.toISOString(), count: 1 })
      .eq('profile_id', profileId)
      .eq('action', action);
    return { allowed: true as const };
  }

  if (existing.count >= max) {
    return {
      allowed: false as const,
      retryAfterSeconds: Math.ceil(windowSeconds - elapsedSeconds),
    };
  }

  await supabaseAdmin
    .from('rate_limits')
    .update({ count: existing.count + 1 })
    .eq('profile_id', profileId)
    .eq('action', action);

  return { allowed: true as const };
}
