import { createClient, SupabaseClient } from '@supabase/supabase-js';

// This is the anon (public) client. It only ever gets as much access as the
// RLS policies in supabase/schema.sql grant it — never use the service_role
// key here or anywhere else in client-shipped code.
//
// LAZY INIT: validated on first use rather than at import time, so this
// module can be imported (and the app/build can proceed) even in an
// environment where the public env vars aren't set yet — it will only
// throw once a component actually tries to talk to Supabase.
let cachedClient: SupabaseClient | null = null;

function getClient(): SupabaseClient {
  if (cachedClient) return cachedClient;

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error(
      'Missing NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY. ' +
        'Copy .env.local.example to .env.local and fill in your own project values, ' +
        'or set them in your Vercel Project Settings → Environment Variables.'
    );
  }

  cachedClient = createClient(supabaseUrl, supabaseAnonKey, {
    auth: {
      // We run our own pseudonymous nickname/password login (see lib/session.ts),
      // not Supabase Auth, so no need to persist a Supabase auth session here.
      persistSession: false,
    },
  });
  return cachedClient;
}

export const supabase: SupabaseClient = new Proxy({} as SupabaseClient, {
  get(_target, prop, receiver) {
    const client = getClient();
    const value = Reflect.get(client, prop, receiver);
    return typeof value === 'function' ? value.bind(client) : value;
  },
});
