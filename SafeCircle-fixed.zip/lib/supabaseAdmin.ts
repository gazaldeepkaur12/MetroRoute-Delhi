import 'server-only';
import { createClient, SupabaseClient } from '@supabase/supabase-js';

// DANGER: this client bypasses Row Level Security entirely. It must only
// ever be imported from server-only code (route handlers, server actions).
// The `server-only` import above will throw a build error if anything
// tries to pull this into a client bundle.
//
// LAZY INIT: env vars are validated on first *use*, not on import. Next.js
// can statically analyze/collect route modules at build time even when the
// real Supabase env vars aren't set (e.g. a Vercel build without them
// configured yet), and eagerly throwing here would fail the build itself
// instead of failing gracefully at request time. A Proxy defers both
// validation and client creation until a property (e.g. `.from(...)`) is
// actually accessed while handling a real request.
let cachedClient: SupabaseClient | null = null;

function getClient(): SupabaseClient {
  if (cachedClient) return cachedClient;

  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!supabaseUrl || !serviceRoleKey) {
    throw new Error(
      'Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY. ' +
        'Set these in .env.local (server-only — never expose the service role key to the client) ' +
        'or in your Vercel Project Settings → Environment Variables.'
    );
  }

  cachedClient = createClient(supabaseUrl, serviceRoleKey, {
    auth: { persistSession: false },
  });
  return cachedClient;
}

export const supabaseAdmin: SupabaseClient = new Proxy({} as SupabaseClient, {
  get(_target, prop, receiver) {
    const client = getClient();
    const value = Reflect.get(client, prop, receiver);
    return typeof value === 'function' ? value.bind(client) : value;
  },
});
