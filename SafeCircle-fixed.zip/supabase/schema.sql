-- ============================================================================
-- Protest Chat & Safe Spots — Database schema
--
-- HOW TO RUN:
--   Supabase Dashboard -> SQL Editor -> paste this whole file -> Run.
--
-- SECURITY MODEL (read this before changing anything):
--   1. There is NO Supabase Auth user here. "Login" is a custom
--      nickname + password system (see lib/auth.ts / app/api/auth/*).
--      Passwords are hashed server-side with bcrypt and NEVER touch the
--      browser or this table's RLS-exposed surface.
--   2. The anon/publishable key (safe to ship to the browser) is ONLY
--      ever granted SELECT on public, non-sensitive data. All INSERT/UPDATE
--      goes through Next.js server actions using the service_role key,
--      so every write passes through our own session + rate-limit checks
--      first. RLS on this DB defaults to deny-all for anon; each policy
--      below is a deliberate, minimal exception.
--   3. `profiles` (which holds the password hash) has NO anon policies at
--      all — it is completely invisible to the browser-side client.
--   4. Locations are stored ALREADY ROUNDED/JITTERED (~100-150m) at the
--      application layer before insert. We never store or expose exact
--      GPS coordinates for safe spots.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- profiles: pseudonymous accounts. Nickname + password hash ONLY.
-- No email, phone, government ID, or real name — ever.
-- ----------------------------------------------------------------------------
create table if not exists profiles (
  id uuid primary key default gen_random_uuid(),
  nickname text unique not null check (char_length(nickname) between 3 and 24),
  password_hash text not null,
  created_at timestamptz not null default now(),
  last_seen_at timestamptz not null default now(),
  is_muted boolean not null default false
);

alter table profiles enable row level security;
-- Intentionally NO policies for anon: this table is only ever touched by
-- server actions using the service_role key, which bypasses RLS entirely.

-- ----------------------------------------------------------------------------
-- rooms: globally visible, joinable by anyone with a nickname/session.
-- ----------------------------------------------------------------------------
create table if not exists rooms (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null check (char_length(name) between 2 and 40),
  description text default '',
  is_fixed boolean not null default false, -- true for General / Legal Help / Medical
  created_by uuid references profiles(id) on delete set null,
  created_at timestamptz not null default now()
);

alter table rooms enable row level security;

create policy "rooms are publicly readable"
  on rooms for select
  to anon
  using (true);

-- No anon insert/update/delete policy: room creation goes through a server
-- action (service_role) so we can validate the nickname session + basic
-- content rules before a room becomes globally visible.

-- ----------------------------------------------------------------------------
-- messages: text/photo/video references, tied to a room + nickname (not id
-- exposed unnecessarily). Realtime subscribes to this table's inserts.
-- ----------------------------------------------------------------------------
create table if not exists messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references rooms(id) on delete cascade,
  sender_nickname text not null,
  sender_profile_id uuid references profiles(id) on delete set null,
  body text,
  media_url text, -- storage path, only ever set after EXIF-stripping on upload
  media_type text check (media_type in ('image', 'video', 'audio', null)),
  created_at timestamptz not null default now()
);

alter table messages enable row level security;

create policy "messages are publicly readable"
  on messages for select
  to anon
  using (true);

-- No anon insert policy: all sends go through /api/messages server action,
-- which checks the session cookie, applies rate limiting, and strips media
-- metadata before writing here.

create index if not exists messages_room_id_created_at_idx
  on messages (room_id, created_at desc);

-- ----------------------------------------------------------------------------
-- safe_spots: user-suggested locations. Coordinates are ALREADY rounded /
-- jittered by the app before insert — this table never holds precise GPS.
-- ----------------------------------------------------------------------------
create table if not exists safe_spots (
  id uuid primary key default gen_random_uuid(),
  category text not null check (category in ('hiding', 'medical', 'legal_help', 'rest', 'water_food', 'other')),
  description text not null check (char_length(description) between 5 and 300),
  -- Rounded/jittered coordinates only (~100-150m grid). Never exact.
  approx_lat double precision not null,
  approx_lng double precision not null,
  status text not null default 'pending' check (status in ('pending', 'verified', 'rejected')),
  submitted_by uuid references profiles(id) on delete set null,
  confirmations_count int not null default 0,
  created_at timestamptz not null default now(),
  verified_at timestamptz
);

alter table safe_spots enable row level security;

-- Only VERIFIED spots are visible to the public. Pending spots are only
-- readable by server actions (service_role) — e.g. to show "your pending
-- submissions" back to the submitter via a signed session check, not raw RLS.
create policy "verified safe spots are publicly readable"
  on safe_spots for select
  to anon
  using (status = 'verified');

-- No anon insert/update policy: submission + confirmation go through server
-- actions so we can enforce location rounding, rate limits, and the
-- N-confirmations-to-verify rule server-side.

create index if not exists safe_spots_status_idx on safe_spots (status);

-- ----------------------------------------------------------------------------
-- safe_spot_confirmations: one confirmation per profile per spot (dedup).
-- Not readable by anon at all; only used internally by the server action
-- that tallies confirmations_count on safe_spots.
-- ----------------------------------------------------------------------------
create table if not exists safe_spot_confirmations (
  spot_id uuid not null references safe_spots(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (spot_id, profile_id)
);

alter table safe_spot_confirmations enable row level security;
-- No anon policies at all.

-- ----------------------------------------------------------------------------
-- rate_limits: lightweight per-profile counters so one nickname can't flood
-- chat or spam safe-spot submissions. Checked/updated only by server actions.
-- ----------------------------------------------------------------------------
create table if not exists rate_limits (
  profile_id uuid not null references profiles(id) on delete cascade,
  action text not null check (action in ('message', 'safe_spot_submit', 'confirmation', 'room_create')),
  window_start timestamptz not null default now(),
  count int not null default 0,
  primary key (profile_id, action)
);

alter table rate_limits enable row level security;
-- No anon policies at all.

-- ----------------------------------------------------------------------------
-- Seed the three fixed rooms (safe to re-run: ON CONFLICT DO NOTHING).
-- ----------------------------------------------------------------------------
insert into rooms (slug, name, description, is_fixed)
values
  ('general', 'General', 'Open discussion — keep it respectful and on-topic.', true),
  ('legal-help', 'Legal Help', 'Know-your-rights info, legal aid contacts, what to do if detained.', true),
  ('medical', 'Medical', 'First aid help, medical volunteers, health concerns.', true)
on conflict (slug) do nothing;

-- ----------------------------------------------------------------------------
-- Storage: create a bucket for chat media (photos/short videos/voice notes).
-- Run this separately if using the Supabase Storage UI, or via the
-- storage.buckets insert below. Files are uploaded through a server route
-- that strips EXIF before writing to storage, and bucket is public-read
-- only for files that have already passed that step.
-- ----------------------------------------------------------------------------
insert into storage.buckets (id, name, public)
values ('chat-media', 'chat-media', true)
on conflict (id) do nothing;
