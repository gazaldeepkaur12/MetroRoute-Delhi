declare module 'leaflet.offline';
